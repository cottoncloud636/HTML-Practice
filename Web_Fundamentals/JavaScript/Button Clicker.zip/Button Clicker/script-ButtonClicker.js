//alert message
function msg(){
    alert("Ninja was liked"); //alert is a built-in js function, only console out a message, does not need to pass a parameter to tell it to execute
}

//remove a button onclick
function hide(addbtn){
    addbtn.remove(); //"this" addbtn execute remove function
}

//change "Login" to "Logout" onclick
function change(element){
    if(element.innerText=="Login"){
        element.innerText="Logout";
    // } else{
    //     element.innerText="Login"
    // // }
}
}