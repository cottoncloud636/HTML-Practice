console.log("page loaded...");

function playvideo(video){
    video.play();
}

function pausevideo(video){
    video.pause();
    video.currentTime = 0; //when mouse out, reset the video from start
}